﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;
using HotelManagementWebAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryRepository _inventoryRepository;

        public InventoryController(IInventoryRepository inventoryRepository)
        {
            _inventoryRepository = inventoryRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<Inventory>> GetInventories()
        {
            return await _inventoryRepository.GetInventories();

        }
        [HttpGet("{InventoryId}")]
        public async Task<ActionResult<Inventory>> GetInventory(int InventoryId)
        {
            return await _inventoryRepository.Get(InventoryId);

        }
        [HttpPost]
        public async Task<ActionResult<Inventory>> PostInventories([FromBody] Inventory inventory)
        {
            var newInventory = await _inventoryRepository.Create(inventory);
            return CreatedAtAction(nameof(GetInventories), new { InventoryId = newInventory }, newInventory);
        }
        [HttpPut]
        public async Task<ActionResult> PutInventories(int InventoryId, [FromBody] Inventory inventory)
        {
            if (InventoryId != inventory.InventoryId)
            {
                return BadRequest();
            }
            await _inventoryRepository.Update(inventory);
            return NoContent();
        }
        [HttpDelete("{InventoryId}")]
        public async Task<ActionResult> Delete(int InventoryId)
        {
            var inventoryToDelete = await _inventoryRepository.Get(InventoryId);
            if (inventoryToDelete == null)
            {
                return NotFound();

            }
            await _inventoryRepository.Delete(inventoryToDelete.InventoryId);
            return NoContent();
        }
    }
}
