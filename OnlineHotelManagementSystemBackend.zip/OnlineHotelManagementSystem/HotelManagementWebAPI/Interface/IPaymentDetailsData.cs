﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Interface
{
    public interface IPaymentDetailsData<T>
    {
        Task<PaymentDetails> Get(int PaymentId);
        Task<PaymentDetails> AddPaymentDetails(PaymentDetailsData paymentData);
        Task Delete(int PaymentId);
    }
}
