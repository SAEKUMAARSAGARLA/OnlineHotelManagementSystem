﻿namespace HotelManagementWebAPI.Data
{
    public class InvoiceData
    {
        public int InvoiceId { get; set; }
        public int? MemberCode { get; set; }
        public int RoomPrice { get; set; }
        public int ServicesCost { get; set; }
        public int Total { get; set; }
    }
}
