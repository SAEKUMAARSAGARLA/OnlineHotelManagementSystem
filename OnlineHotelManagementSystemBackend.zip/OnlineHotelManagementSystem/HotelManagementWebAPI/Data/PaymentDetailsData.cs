﻿using System;

namespace HotelManagementWebAPI.Data
{
    public class PaymentDetailsData
    {
        public int PaymentId { get; set; }
        public DateTime PaymentTime { get; set; }
        public string PaymentMethod { get; set; }
        public int? MemberCode { get; set; }
        public int? InvoiceId { get; set; }
        public int Total { get; set; }
    }
}
