﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public interface IInventoryRepository
    {
        Task<IEnumerable<Inventory>> GetInventories();
        Task<Inventory> Get(int InventoryId);
        Task<Inventory> Create(Inventory inventory);
        Task Update(Inventory inventory);
        Task Delete(int InventoryId);
    }
}
