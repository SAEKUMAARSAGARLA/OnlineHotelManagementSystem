﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public class InvoiceRepository : IInvoiceData<Invoice>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public InvoiceRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<Invoice> Get(int InvoiceId)
        {
            return await _onlineHotelManagementContext.Invoice.FindAsync(InvoiceId);
        }
        public async Task<Invoice> AddInvoice(InvoiceData invoiceData)
        {
            var invoice = new Invoice()
            {
                InvoiceId = invoiceData.InvoiceId,
                MemberCode = invoiceData.MemberCode,
                RoomPrice = invoiceData.RoomPrice,
                ServicesCost = invoiceData.ServicesCost,
                Total = invoiceData.Total,
            };
            if (invoice == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.Invoice.AddAsync(invoice);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return invoice;
        }
        public async Task Delete(int InvoiceId)
        {
            var invoiceToDelete = await _onlineHotelManagementContext.Invoice.FindAsync(InvoiceId);
            _onlineHotelManagementContext.Invoice.Remove(invoiceToDelete);
            _onlineHotelManagementContext.SaveChanges();
        }
    }
}
