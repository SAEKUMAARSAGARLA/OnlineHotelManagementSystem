﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementWebAPI.Repository
{
    public class TypeOfRoomRepository : ITypeOfRoomData<TypeOfRoom>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public TypeOfRoomRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<IEnumerable<TypeOfRoom>> Get()
        {
            return await _onlineHotelManagementContext.TypeOfRoom.ToListAsync();
        }
        public async Task<TypeOfRoom> AddRoom(TypeOfRoomData roomData)
        {
            var newRoom = new TypeOfRoom()
            {
                RoomType = roomData.RoomType,
                Adults = roomData.Adults,
                Child = roomData.Child,
                StandardPrice = roomData.StandardPrice,

            };
            if (newRoom == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.TypeOfRoom.AddAsync(newRoom);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return newRoom;
        }

    }
}
