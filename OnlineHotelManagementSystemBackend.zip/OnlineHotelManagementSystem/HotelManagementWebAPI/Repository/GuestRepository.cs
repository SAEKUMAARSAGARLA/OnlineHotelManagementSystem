﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementWebAPI.Repository
{
    public class GuestRepository : IGuestData<Guest>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public GuestRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<IEnumerable<Guest>> Get()
        {
            return await _onlineHotelManagementContext.Guest.ToListAsync();
        }

        public async Task<Guest> Get(int MemberCode)
        {
            return await _onlineHotelManagementContext.Guest.FindAsync(MemberCode);
        }
        public async Task<Guest> AddUser(GuestData guestData)
        {
            var guest = new Guest()
            {
                MemberCode = guestData.MemberCode,
                Name = guestData.Name,
                Age = guestData.Age,
                MobileNumber = guestData.MobileNumber,
                Gender = guestData.Gender,
                City = guestData.City,
                Pincode = guestData.Pincode,
                Citizenship = guestData.Citizenship,
                Occupation = guestData.Occupation,
                DrivingLicence = guestData.DrivingLicence,
                Email = guestData.Email,
            };
            if (guest == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.Guest.AddAsync(guest);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return guest;
        }
        public async Task Delete(int MemberCode)
        {
            var guestToDelete = await _onlineHotelManagementContext.Guest.FindAsync(MemberCode);
            _onlineHotelManagementContext.Guest.Remove(guestToDelete);
            _onlineHotelManagementContext.SaveChanges();
        }
    }
}
