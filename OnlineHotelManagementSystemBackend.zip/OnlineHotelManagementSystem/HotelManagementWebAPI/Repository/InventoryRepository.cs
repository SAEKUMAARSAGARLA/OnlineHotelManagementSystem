﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementWebAPI.Repository
{
    public class InventoryRepository : IInventoryRepository
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public InventoryRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<IEnumerable<Inventory>> GetInventories()
        {
            return await _onlineHotelManagementContext.Inventory.ToListAsync();
        }
        public async Task<Inventory> Get(int InventoryId)
        {
            return await _onlineHotelManagementContext.Inventory.FindAsync(InventoryId);

        }
        public async Task<Inventory> Create(Inventory inventory)
        {
            _onlineHotelManagementContext.Inventory.Add(inventory);

            await _onlineHotelManagementContext.SaveChangesAsync();
            return inventory;
        }
        public async Task Update(Inventory inventory)
        {
            _onlineHotelManagementContext.Entry(inventory).State = EntityState.Modified;
            await _onlineHotelManagementContext.SaveChangesAsync();
        }
        public async Task Delete(int InventoryId)
        {
            var inventoryToDelete = await _onlineHotelManagementContext.Inventory.FindAsync(InventoryId);
            _onlineHotelManagementContext.Inventory.Remove(inventoryToDelete);
            _onlineHotelManagementContext.SaveChanges();
        }
    }
}
